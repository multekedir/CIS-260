
/**
 * @author  Multezem Kedir
 *          Jim	Bailey
 *          CS 260
 *          Project 1
 *          4/12/2017 
 */
public class ArrayClass {

    private int data[]; 
    private int index; //number of elements

    /**
     * creates an array of 100 elements
    */
    public ArrayClass() {
        data = new int[100];
        index = 0;
    }
    
    /**
     * creates an array of n elements
     * @param n number of element
    */
    public ArrayClass(int n) {
        data = new int[n];
        index = 0;
    }
    /**
     * adds the integer 'n' to the array in the next available location,
     *
     * @param n element to be added in array
     * @return true if added
     */
    boolean addElem(int n) {
        if (this.index < data.length) { //check size
            this.data[this.index] = n;
            this.index++;
            return true;
        }
        return false;
    }
      
    
    /**
     * deletes the last added element
     * @return false if array is empty
     */ 
    boolean delElem(){
        if(index == 0){
            return false;
        }else{
            data[--index] = -1;
           // index--;
            return true;
        }       
    }

     /**
     * gets the largest element and then removes it
     * @return true if removed
     */
    public int getLargest() {
        int largest = data[0];
        for (int i = 0; i < howMany(); i++) {
            if (data[i] >= largest) {
                largest = data[i]; // get largest element
            }
        }
        //delet
        for (int i = 0; i < howMany(); i++) {
            if (data[i] == largest) {
                data[i] = data[index-1]; //set last element to new position
                delElem();
                return largest;
            }
        }
        return largest;
    }
    
     /**
     * removes any duplicate entries.
     */
    public void deleteDups() {
        for (int i = 0; i < howMany(); i++) {
            for (int j = i + 1; j <= howMany(); j++) {
                if (data[i] == data[j] && i != j) {
                    data[j] = data[index-1]; //set last element to new position
                    delElem();
                    j--;
                }
            }
        }
    }
    
    
    /**
     * @return the number of elements in the array
     */   
    public int howMany() {
        return this.index;
    }
    
    /**
     * @return string listing Array elements, ten per line
     */
    public String curElems() {
        String output = "";
        for (int i = 0; i < howMany(); i++) {
            if (i % 10 == 0) {
                output += "\n";
            }
            output += " " + Integer.toString(data[i]);
        }
        return output;
    }
    
}
