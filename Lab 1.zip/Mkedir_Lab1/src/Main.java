
/**
 * @author  Multezem Kedir
 *          Jim	Bailey
 *          CS 260
 *          Project 1
 *          4/12/2017
 */
import java.util.Random;

public class Main {

    ArrayClass arr = new ArrayClass(10);
    ArrayClass arrSorted = new ArrayClass(10);
    Random rand = new Random();

    public Main() {
        System.out.print("populating array with random numbers");
        //populate array with random numbers
        for (int i = 0; i < 10; i++) {
            int n = rand.nextInt(10) + 1;
            arr.addElem(n);
        }
        System.out.println(arr.curElems());
        //question #2
        System.out.print("Largest number: " + arr.getLargest());
        System.out.println(arr.curElems());
        //question #3
        System.out.print("Removing duplicate entries.");
        arr.deleteDups();
        System.out.println(arr.curElems());
        //question #4
        System.out.println("Sorting Data");
        int[] sorted = sorted(arrSorted);
        for (int i = 0; i < sorted.length; i++) {
            System.out.print(sorted[i]+" ");
        }
        System.out.println("");
    }
    int[] sorted(ArrayClass parm) {
        for (int i = 0; i < 10; i++) {
            int n = rand.nextInt(10) + 1;
            parm.addElem(n);
        }
        int[] out = new int[parm.howMany()];
        int i = 0;
        do {
            out[i] = parm.getLargest();
            i++;
        } while (parm.howMany() != 0);
        return out;
    }
    
    public static void main(String[] args) {
        Main m = new Main();
    }

}
